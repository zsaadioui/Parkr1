//
//  ViewController.swift
//  Parkr1
//
//  Created by Zack on 11/13/18.
//  Copyright © 2018 Zack. All rights reserved.
//

import UIKit

import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func createAccountTapped(_ sender: Any) {
        
        if let email = emailTextField.text, let password = passwordTextField.text{
            
            
            Auth.auth().createUser(withEmail: email, password: password, completion:  { user, error in
                
                
                if let firebaseError = error {
                    print(firebaseError.localizedDescription)
                    return
                }
                print("success")
            
            })
        }
    }
    
    @IBAction func loginTapped(_ sender: Any) {
        if let email = emailTextField.text, let password = passwordTextField.text {
            Auth.auth().signIn(withEmail: email, password: password, completion: { (user, error) in
                
                if let firebaseError = error {
                    print(firebaseError.localizedDescription)
                    return
                }
                print("success")
            })
        }
    }
    
    
}

