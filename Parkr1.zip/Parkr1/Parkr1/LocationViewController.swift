//
//  LocationViewController.swift
//  Parkr
//
//  Created by Dylan Fay on 11/12/18.
//  Copyright © 2018 Dylan Fay. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var address: UILabel!
    
    var locationManager : CLLocationManager!
    var previousAddress: String!
    var geoCoder: CLGeocoder!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        locationManager.requestLocation()
        geoCoder = CLGeocoder()

        // Do any additional setup after loading the view.
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let location: CLLocation = locations.first!
        self.mapView.centerCoordinate = location.coordinate
        let reg = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1500, longitudinalMeters: 1500)
        self.mapView.setRegion(reg, animated: true)
        geoCode(location: location)
        
        }
    
   func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
   }
    
    func geoCode(location: CLLocation!){
        
        geoCoder.cancelGeocode()
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (data, error) -> Void in guard let placeMarks = data as [CLPlacemark]! else {
            return
            }
            let loc: CLPlacemark = placeMarks[0]
            let address = "\(loc.thoroughfare ?? ""), \(loc.locality ?? ""), \(loc.subLocality, ""), \(loc.administrativeArea ?? ""), \(loc.postalCode ?? ""), \(loc.country ?? "")"
           // let addressDict : [NSString:NSObject] = loc.addressDictionary as! [NSString: NSObject]
            //let addrList = addressDict["FormattedAddressLines"] as! [String]
            //let address = ", ".join(addrList)
            print(address)
            self.address.text = address
            self.previousAddress = address
            
            })
        
        
        
    }
    
    
    
    

}
